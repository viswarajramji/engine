package com.engine.sale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaleServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
